/**
 * src/js/core/ics.js
 * GENERADOR DE ALARMAS ICS
 * Crea un archivo de calendario para sincronizar con Google/Apple Calendar.
 */

import { QumranData } from './data.js';
import { QumranCalendar } from './calendar.js';

export const QumranICS = {
    generateAndDownload: (year) => {
        let test = new Date(year, 2, 5);
        let icsContent = [
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//Qumran Watch//ES",
            "CALSCALE:GREGORIAN",
            "X-WR-CALNAME:Qumran Watch — Fiestas Sagradas",
            "X-WR-CALDESC:Calendario solar de 364 días. Manuscritos del Mar Muerto.",
            "X-WR-TIMEZONE:UTC",
        ];

        for (let i = 0; i < 380; i++) {
            let d = new Date(test.getTime() + (i * 86400000));
            let q = QumranCalendar.calculate(d);
            if (!q || q.special) continue;

            // Fiestas (Moedim)
            let fIdx = QumranData.FIESTAS.findIndex(x => x.m === q.m && x.d === q.d);
            if (fIdx !== -1) {
                let f = QumranData.FIESTAS[fIdx];
                let dateStr = d.toISOString().replace(/-|:|\.\d+/g, '').substring(0, 8);
                let uid = `qw-fiesta-${fIdx}-${dateStr}@qumranwatch`;

                icsContent.push(
                    "BEGIN:VEVENT",
                    `UID:${uid}`,
                    `SUMMARY:🕍 ${f.n}`,
                    `DESCRIPTION:${f.es}\\n${f.instr || ''}\\n\\nRef: ${f.ref || ''}`,
                    `DTSTART;VALUE=DATE:${dateStr}`,
                    `DTEND;VALUE=DATE:${dateStr}`,
                    "CATEGORIES:FIESTAS-SAGRADAS",
                    "BEGIN:VALARM",
                    "TRIGGER:-P1D",
                    "ACTION:DISPLAY",
                    `DESCRIPTION:Mañana: ${f.n}`,
                    "END:VALARM",
                    "END:VEVENT"
                );
            }

            // Shabat semanal
            if (q.idxSem === 6) {
                let dateStr = d.toISOString().replace(/-|:|\.\d+/g, '').substring(0, 8);
                let uid = `qw-shabat-${dateStr}@qumranwatch`;

                icsContent.push(
                    "BEGIN:VEVENT",
                    `UID:${uid}`,
                    "SUMMARY:✡ Shabat (Calendario Qumrán)",
                    "DESCRIPTION:Día de reposo según el calendario solar de 364 días.",
                    `DTSTART;VALUE=DATE:${dateStr}`,
                    `DTEND;VALUE=DATE:${dateStr}`,
                    "CATEGORIES:SHABAT",
                    "BEGIN:VALARM",
                    "TRIGGER:-PT12H",
                    "ACTION:DISPLAY",
                    "DESCRIPTION:Prepárate: El Shabat comienza al amanecer de mañana",
                    "END:VALARM",
                    "END:VEVENT"
                );
            }
        }

        icsContent.push("END:VCALENDAR");

        const blob = new Blob([icsContent.join('\n')], { type: 'text/calendar;charset=utf-8' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Qumran_Moedim_${year}.ics`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
};