/**
 * src/js/ui/modal.js
 * Gestión de modales con focus trap y roles ARIA correctos.
 * Cumple WCAG 2.2 criterios 2.1.1, 2.1.2, 4.1.2.
 */

export const ModalManager = {

    _activeModal: null,
    _previousFocus: null,
    _focusableSelectors: [
        'a[href]', 'button:not([disabled])', 'input:not([disabled])',
        'select:not([disabled])', 'textarea:not([disabled])',
        '[tabindex]:not([tabindex="-1"])'
    ].join(','),

    open: (modalId) => {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        // Guardar el foco actual para restaurarlo al cerrar
        ModalManager._previousFocus = document.activeElement;
        ModalManager._activeModal = modal;

        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';

        // Mover foco al primer elemento enfocable dentro del modal
        const firstFocusable = modal.querySelector(ModalManager._focusableSelectors);
        if (firstFocusable) {
            setTimeout(() => firstFocusable.focus(), 50);
        }

        // Trap de foco
        modal.addEventListener('keydown', ModalManager._trapFocus);
        // Cerrar con Escape
        document.addEventListener('keydown', ModalManager._handleEscape);
        // Cerrar al hacer click fuera
        modal.addEventListener('click', ModalManager._handleOutsideClick);
    },

    close: (modalId) => {
        const modal = modalId
            ? document.getElementById(modalId)
            : ModalManager._activeModal;

        if (!modal) return;

        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';

        modal.removeEventListener('keydown', ModalManager._trapFocus);
        document.removeEventListener('keydown', ModalManager._handleEscape);
        modal.removeEventListener('click', ModalManager._handleOutsideClick);

        // Restaurar foco al elemento que lo tenía antes
        if (ModalManager._previousFocus && ModalManager._previousFocus.focus) {
            ModalManager._previousFocus.focus();
        }

        ModalManager._activeModal = null;
        ModalManager._previousFocus = null;
    },

    _trapFocus: (e) => {
        if (e.key !== 'Tab') return;
        const modal = ModalManager._activeModal;
        if (!modal) return;

        const focusables = Array.from(modal.querySelectorAll(ModalManager._focusableSelectors));
        if (focusables.length === 0) return;

        const first = focusables[0];
        const last  = focusables[focusables.length - 1];

        if (e.shiftKey) {
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    },

    _handleEscape: (e) => {
        if (e.key === 'Escape' && ModalManager._activeModal) {
            ModalManager.close();
        }
    },

    _handleOutsideClick: (e) => {
        if (e.target === ModalManager._activeModal) {
            ModalManager.close();
        }
    }
};