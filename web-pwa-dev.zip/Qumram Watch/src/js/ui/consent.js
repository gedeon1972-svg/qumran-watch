/**
 * src/js/ui/consent.js
 * Gestión de consentimiento RGPD para geolocalización.
 * Obligatorio bajo RGPD Art. 6 y 13 (UE 2016/679).
 */

const CONSENT_KEY  = 'qw_geo_consent';
const CONSENT_DATE = 'qw_geo_consent_date';

export const ConsentManager = {

    hasConsent: () => localStorage.getItem(CONSENT_KEY) === 'granted',
    hasDenied:  () => localStorage.getItem(CONSENT_KEY) === 'denied',
    isDecided:  () => localStorage.getItem(CONSENT_KEY) !== null,

    grant: () => {
        localStorage.setItem(CONSENT_KEY, 'granted');
        localStorage.setItem(CONSENT_DATE, new Date().toISOString());
        ConsentManager.hideBanner();
    },

    deny: () => {
        localStorage.setItem(CONSENT_KEY, 'denied');
        localStorage.setItem(CONSENT_DATE, new Date().toISOString());
        ConsentManager.hideBanner();
    },

    revoke: () => {
        localStorage.removeItem(CONSENT_KEY);
        localStorage.removeItem(CONSENT_DATE);
        localStorage.removeItem('qw_lat');
        localStorage.removeItem('qw_lng');
    },

    showBanner: () => {
        const banner = document.getElementById('consent-banner');
        if (banner) {
            banner.classList.add('is-visible');
            // Focus management para accesibilidad
            const firstBtn = banner.querySelector('button');
            if (firstBtn) firstBtn.focus();
        }
    },

    hideBanner: () => {
        const banner = document.getElementById('consent-banner');
        if (banner) banner.classList.remove('is-visible');
    },

    init: (onGranted) => {
        const btnGrant = document.getElementById('consent-grant');
        const btnDeny  = document.getElementById('consent-deny');

        if (btnGrant) {
            btnGrant.addEventListener('click', () => {
                ConsentManager.grant();
                if (typeof onGranted === 'function') onGranted();
            });
        }

        if (btnDeny) {
            btnDeny.addEventListener('click', () => {
                ConsentManager.deny();
            });
        }

        // Mostrar banner si no ha decidido aún
        if (!ConsentManager.isDecided()) {
            ConsentManager.showBanner();
        }
    }
};