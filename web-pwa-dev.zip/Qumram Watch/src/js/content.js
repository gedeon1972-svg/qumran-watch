/**
 * ================================================================
 * QUMRAN WATCH — ARCHIVO DE CONTENIDO v14.0
 * ================================================================
 *
 * PARA AGREGAR UN ESTUDIO NUEVO:
 * 1. Buscá la sección ESTUDIOS más abajo
 * 2. Copiá un bloque completo que empieza con { y termina con },
 * 3. Pegalo al final de la lista (antes del corchete ] final)
 * 4. Cambiá el título, subtítulo y el texto
 * 5. Guardá el archivo — aparece automáticamente en la app
 *
 * PARA AGREGAR UNA FIESTA:
 * Buscá la sección FIESTAS y seguí el mismo proceso
 *
 * NO toques nada fuera de las secciones marcadas
 * ================================================================
 */

export const QumranContent = {

    // ════════════════════════════════════════════════════════════
    // ESTUDIOS DE LA BIBLIOTECA
    // Para agregar: copiá un bloque {}, pegalo al final, editá
    // ════════════════════════════════════════════════════════════
    ESTUDIOS: [
        {
            // Título del estudio — aparece en la tarjeta y en el modal
            titulo: "El Ancla: La Señal de 2019",

            // Subtítulo corto — aparece bajo el título en la tarjeta
            subtitulo: "La Sincronización del Génesis con nuestra era.",

            // Categoría — aparece como etiqueta (Historia, Calendario, Liturgia, Teología)
            categoria: "Historia · Fundamento",

            // Texto completo — podés usar estas etiquetas:
            // <p>párrafo</p>  |  <strong>negrita</strong>  |  <em>cursiva</em>
            // <ul><li>punto</li></ul>  |  <blockquote>cita bíblica</blockquote>
            texto: `
                <p>Para restaurar el calendario de los Hijos de Sadoc, era necesario identificar un <strong>Punto Cero</strong> en nuestra era que replicara las condiciones exactas de la Semana de la Creación descrita en Génesis 1:14-19.</p>

                <p>El Creador estableció las luminarias en el <strong>Día Cuarto (Miércoles)</strong>. Por tanto, el reloj divino original comenzó con una alineación triple:</p>

                <ul>
                    <li><strong>Día de la Semana:</strong> Miércoles (Día 4)</li>
                    <li><strong>Posición Solar:</strong> Equinoccio de Primavera — inicio del año solar</li>
                    <li><strong>Posición Lunar:</strong> Luna Llena — luminaria mayor de la noche, creada completa</li>
                </ul>

                <p>Investigaciones astronómicas confirmaron que el <strong>20 de Marzo de 2019</strong> ocurrió esta alineación perfecta en Jerusalén: fue Miércoles, fue Equinoccio y hubo Superluna Llena. Además, coincidió con el inicio del turno sacerdotal de <strong>Gamul</strong>, tal como predicen los manuscritos de Qumrán (4Q320).</p>

                <p>Este evento marcó el inicio de un nuevo ciclo de 6 años, sirviendo como el ancla inamovible desde la cual proyectamos todo el calendario.</p>

                <blockquote>«E hizo Dios las dos grandes lumbreras... y las puso en la expansión de los cielos... y fue la tarde y la mañana el día cuarto.» (Génesis 1:16-19)</blockquote>
            `
        },
        {
            titulo: "El Inicio del Día",
            subtitulo: "La Luz vence a las Tinieblas.",
            categoria: "Teología · Práctica",
            texto: `
                <p>Una de las desviaciones más graves del sistema babilónico-rabínico es comenzar el día al atardecer. La Escritura y la práctica del Templo dictan que el día comienza con la <strong>Luz</strong>.</p>

                <p><strong>Evidencia bíblica:</strong> En Génesis 1, Dios llama a la Luz "Día" y a las Tinieblas "Noche". Son entidades separadas. La frase <em>"y fue la tarde y la mañana un día"</em> señala la conclusión de un ciclo de 24 horas, no su comienzo. El orden es: Luz (trabajo) → Oscuridad (descanso) → Nuevo Amanecer.</p>

                <p><strong>Evidencia del Templo:</strong> El sacrificio diario (Tamid) y la limpieza del altar siempre comenzaban con el amanecer. Ningún sacrificio se iniciaba en la oscuridad.</p>

                <p>Por esta razón, Qumran Watch utiliza tu GPS para cambiar la fecha solo cuando el sol aparece en tu horizonte local, restaurando el ritmo biológico y espiritual original.</p>
            `
        },
        {
            titulo: "El Año Perfecto: 364 Días",
            subtitulo: "Orden matemático frente al caos lunar.",
            categoria: "Calendario · Enoc",
            texto: `
                <p>El calendario de Enoc y Jubileos consta de exactamente <strong>364 días</strong>. Es matemáticamente perfecto por una razón única:</p>

                <ul>
                    <li>364 es divisible exactamente por 7 → <strong>52 semanas exactas</strong></li>
                    <li>Las Fiestas de YHWH caen <strong>siempre en el mismo día de la semana</strong>, año tras año, eternamente</li>
                    <li>Pesaj siempre cae en Martes · Shavuot siempre en Domingo · Yom Kipur siempre en Viernes</li>
                </ul>

                <p>El calendario lunar (354 días) requiere añadir un mes extra arbitrario. El gregoriano (365 días) rompe las semanas. Solo el año de 364 mantiene el orden divino sin parches humanos.</p>

                <blockquote>«Y mandarás a los hijos de Israel que observen los años de acuerdo con este cómputo: trescientos sesenta y cuatro días, y esto constituirá un año completo.» (Jubileos 6:32)</blockquote>
            `
        },
        {
            titulo: "El Ciclo Sacerdotal de 6 Años",
            subtitulo: "La sincronización de los Mishmarot.",
            categoria: "Calendario · Historia",
            texto: `
                <p>El año solar real dura 365.25 días, pero el calendario bíblico tiene 364. Existe un desfase anual de 1.25 días. ¿Cómo los Hijos de Sadoc mantenían la alineación con las estaciones?</p>

                <p>Utilizaban un <strong>Ciclo de 6 Años</strong> basado en la rotación de los 24 turnos sacerdotales (1 Crónicas 24). En 6 años el desfase acumula exactamente 7.5 días. Al final del sexto año se añadía una semana intercalar para sincronizar el ciclo solar sin romper la cuenta del Shabat.</p>

                <p><strong>El orden de los años por turno inicial:</strong></p>
                <ul>
                    <li><strong>Año 1:</strong> Gamul (2019 · 2025)</li>
                    <li><strong>Año 2:</strong> Jedaías</li>
                    <li><strong>Año 3:</strong> Mijamín</li>
                    <li><strong>Año 4:</strong> Secanías</li>
                    <li><strong>Año 5:</strong> Jesebeab</li>
                    <li><strong>Año 6:</strong> Hapises</li>
                </ul>

                <p>Este ciclo de 294 años (Gran Jubileo) asegura que el tiempo sagrado y el tiempo astronómico caminen juntos sin error.</p>
            `
        },
        {
            titulo: "Los Hijos de Sadoc",
            subtitulo: "Los guardianes de la Alianza.",
            categoria: "Historia · Teología",
            texto: `
                <p>Los <strong>Bnei Tzadok</strong> son el linaje legítimo de sumos sacerdotes descendientes de Aarón a través de Sadoc, primer Sumo Sacerdote del Templo de Salomón.</p>

                <p>Durante el Segundo Templo, el sacerdocio fue corrompido por la influencia helenista y política. Los Asmoneos usurparon el cargo e impusieron el calendario lunar griego. Los verdaderos sacerdotes de Sadoc se negaron a profanar los tiempos sagrados y se retiraron al desierto de Judea, a Qumrán.</p>

                <p>Allí preservaron los textos que hoy conocemos como los Rollos del Mar Muerto, manteniendo la pureza del calendario solar y esperando la restauración. Usar este calendario es un acto de alineación con ese remanente fiel.</p>

                <blockquote>«Mas los sacerdotes levitas hijos de Sadoc, que guardaron el ordenamiento de mi santuario cuando los hijos de Israel se apartaron de mí, ellos se acercarán a mí para ministrarme.» (Ezequiel 44:15)</blockquote>
            `
        },
        {
            titulo: "Las Fiestas Perdidas",
            subtitulo: "El ciclo completo de las primicias.",
            categoria: "Liturgia · Templo",
            texto: `
                <p>Levítico 23 es el resumen. El <strong>Rollo del Templo (11Q19)</strong> encontrado en Qumrán detalla un ciclo agrícola completo que el sistema rabínico ha olvidado. El patrón es una cuenta de 50 días (Pentecostés) repetida para cada provisión de la tierra:</p>

                <ul>
                    <li><strong>Primicias de Cebada</strong> — Durante los Panes sin Levadura (Mes 1, Día 26)</li>
                    <li><strong>Shavuot — Trigo</strong> — 50 días después (Mes 3, Día 15)</li>
                    <li><strong>Tirosh — Vino Nuevo</strong> — 50 días después del Trigo (Mes 5, Día 3)</li>
                    <li><strong>Yitzhar — Aceite Nuevo</strong> — 50 días después del Vino (Mes 6, Día 22)</li>
                    <li><strong>Ofrenda de Leña</strong> — 6 días de sacrificios de madera tras el Aceite</li>
                </ul>

                <p>Estas fiestas conectan al creyente con la provisión física y espiritual de YHWH en sus estaciones precisas, revelando que cada cosecha era una liturgia, no solo un evento agrícola.</p>
            `
        },
        {
            titulo: "Las Tekufot: Las Cuatro Estaciones",
            subtitulo: "Los días intercalares del horizonte.",
            categoria: "Calendario · Enoc",
            texto: `
                <p>Para llegar a 364 días, el calendario usa trimestres de <strong>30, 30 y 31 días</strong>. Ese día 31 al final de cada trimestre se llama <strong>Tekufah</strong> (Giro de estación).</p>

                <p>Enoc 72 y 82 describen estos 4 días como "líderes" que sirven de puentes entre las estaciones. No son días ordinarios — son días de transición espiritual y astronómica donde el sol cambia de puerta en el horizonte.</p>

                <p>Las cuatro Tekufot corresponden a los equinoccios y solsticios:</p>
                <ul>
                    <li><strong>Tekufat Nisan</strong> — Equinoccio de Primavera (Mes 1, Día 1)</li>
                    <li><strong>Tekufat Tamuz</strong> — Solsticio de Verano (Mes 4, Día 1)</li>
                    <li><strong>Tekufat Tishrei</strong> — Equinoccio de Otoño (Mes 7, Día 1)</li>
                    <li><strong>Tekufat Tevet</strong> — Solsticio de Invierno (Mes 10, Día 1)</li>
                </ul>

                <p>En Qumran Watch, estos días están marcados como el inicio de cada trimestre del calendario.</p>
            `
        },
        {
            titulo: "Guerra de Luz: El Propósito Final",
            subtitulo: "Por qué el calendario es una batalla.",
            categoria: "Teología · Profecía",
            texto: `
                <p>¿Por qué es tan importante el calendario? Según el <strong>Rollo de la Guerra (1QM)</strong>, existe un conflicto cósmico entre los Hijos de la Luz y los Hijos de las Tinieblas.</p>

                <p>El adversario busca <em>"cambiar los tiempos y la ley"</em> (Daniel 7:25) para desconectar a la humanidad de la fuente de poder divino. Guardar el calendario zadokita es un acto de <strong>guerra espiritual</strong>: es declarar lealtad al Rey del Universo y sincronizarse con Su ejército angelical.</p>

                <p>El ejército angelical del Cielo guarda el mismo calendario. Los Cánticos del Sacrificio del Shabat (4Q400-4Q407) describen a los ángeles ofreciendo liturgia en las mismas fiestas y el mismo Shabat que los Hijos de Sadoc guardaban en la tierra. Cuando tú guardas el tiempo correcto, te alineas con el ejército celestial.</p>

                <blockquote>«Hijos de la Luz contra Hijos de las Tinieblas... y el poder del Príncipe de la Luz estará con los hijos de la justicia.» (Rollo de la Guerra — 1QM 1:1-5)</blockquote>
            `
        }

        // ── PARA AGREGAR UN ESTUDIO NUEVO ─────────────────────────
        // Copiá el bloque de ejemplo de abajo, pegalo aquí arriba
        // (antes de este comentario), y editá el contenido:
        //
        // {
        //     titulo: "Título de tu estudio",
        //     subtitulo: "Una línea corta que describe el tema.",
        //     categoria: "Historia · Teología",
        //     texto: `
        //         <p>Tu primer párrafo aquí.</p>
        //         <p>Tu segundo párrafo aquí.</p>
        //         <blockquote>Una cita bíblica aquí. (Referencia)</blockquote>
        //     `
        // },
        // ─────────────────────────────────────────────────────────
    ],


    // ════════════════════════════════════════════════════════════
    // GLOSARIO DE TÉRMINOS
    // Para agregar: copiá un bloque {}, pegalo al final, editá
    // ════════════════════════════════════════════════════════════
    GLOSARIO: [
        {
            termino: "Mishmar / Mishmarot",
            definicion: "Turno de guardia sacerdotal. Los 24 linajes sacerdotales se rotaban semanalmente para servir en el Templo (1 Crónicas 24). El turno que inicia cada año bíblico sirve como 'firma' del ciclo de 6 años."
        },
        {
            termino: "Tekufah",
            definicion: "Giro de estación. Los 4 días intercalares del calendario — uno por cada estación — que actúan como puentes entre los trimestres. En ellos el sol cambia de Puerta en el horizonte."
        },
        {
            termino: "Puerta Solar",
            definicion: "Sistema de Enoc (Libro de los Luminares, cap. 72-82) que divide el horizonte en 6 posiciones por donde sale y se pone el sol a lo largo del año. La puerta activa indica la posición del sol en su ciclo anual."
        },
        {
            termino: "Moedim",
            definicion: "Las Fiestas Señaladas de YHWH (Levítico 23). Literalmente 'tiempos de encuentro' fijados desde la creación. No son fiestas judías — son citas del Creador con la humanidad."
        },
        {
            termino: "Halajah",
            definicion: "Instrucción práctica derivada de la Torá. En este contexto, la instrucción semanal del Mesías — una enseñanza concreta para vivir en el tiempo correcto."
        },
        {
            termino: "Bnei Tzadok",
            definicion: "Hijos de Sadoc. El linaje sacerdotal legítimo que preservó el calendario solar en Qumrán después de que el sacerdocio del Segundo Templo fuera corrompido por la influencia helenista."
        },
        {
            termino: "Tekelet",
            definicion: "Azul-violeta. El color sagrado del tabernáculo, obtenido del molusco Murex. Simboliza el cielo y el trono divino. Las franjas del talit debían ser de tekelet según Números 15:38."
        },
        {
            termino: "Shir Shel Yom",
            definicion: "Cántico del Día. Cada día de la semana tenía un Salmo específico que los levitas cantaban en el Templo. Esta práctica está documentada en la Mishnah (Tamid 7:4) y en los manuscritos de Qumrán."
        },
        {
            termino: "Tamid",
            definicion: "Sacrificio continuo. La ofrenda quemada que se realizaba cada amanecer y cada atardecer en el Templo. Comenzaba siempre con el amanecer — evidencia de que el día bíblico comienza con la luz."
        },
        {
            termino: "Tirosh",
            definicion: "Vino nuevo. La fiesta de las primicias del vino, celebrada en el Mes 5 Día 3, 50 días después de Shavuot. Documentada en el Rollo del Templo (11Q19) pero ausente del calendario rabínico moderno."
        },
        {
            termino: "Yitzhar",
            definicion: "Aceite nuevo. La fiesta de las primicias del aceite de oliva, celebrada en el Mes 6 Día 22, 50 días después de Tirosh. También documentada solo en el Rollo del Templo."
        },
        {
            termino: "Jubileos",
            definicion: "El Libro de los Jubileos (también llamado el Pequeño Génesis). Texto del siglo II a.C. encontrado en Qumrán que relata la historia desde la creación hasta el Éxodo, con énfasis en el calendario solar de 364 días."
        }

        // ── PARA AGREGAR UN TÉRMINO ───────────────────────────────
        // {
        //     termino: "Tu término en hebreo o español",
        //     definicion: "Explicación clara y directa del término."
        // },
        // ─────────────────────────────────────────────────────────
    ],


    // ════════════════════════════════════════════════════════════
    // TEXTOS DE LA COMUNIDAD
    // Editá directamente los textos sin agregar bloques
    // ════════════════════════════════════════════════════════════
    COMUNIDAD: {
        intro: "Conectate con la comunidad que camina en el orden litúrgico restaurado.",
        podcast: {
            titulo: "Diseñados para Gobernar",
            descripcion: "Podcast propio de Qumran Watch. Recuperá tu gobierno interior a través del análisis profundo de la Escritura y el Calendario Solar.",
            url: "https://youtube.com/playlist?list=PLr4MABEXstnDLUVcD7EenO4vN8EglZoSz"
        },
        instituto: {
            titulo: "Instituto Descubre la Biblia",
            descripcion: "Formación bíblica profunda con raíces en los manuscritos originales. Recurso recomendado para profundizar.",
            url: "https://www.descubrelabiblia.online/"
        },
        telegram: {
            titulo: "Canal de Telegram",
            descripcion: "Recibí las novedades de Qumran Watch directamente en tu celular.",
            url: "https://t.me/+VuFNIOUSMERrLLiD"
        }
    },


    // ════════════════════════════════════════════════════════════
    // TEXTOS GENERALES DEL SITIO
    // Editá directamente sin agregar bloques
    // ════════════════════════════════════════════════════════════
    SITIO: {
        nombre:      "Qumran Watch",
        tagline:     "El Calendario Solar Original de la Escritura",
        descripcion: "364 días. 52 semanas exactas. Las Fiestas de YHWH siempre en el mismo día de la semana. Restaurado desde los textos de los Hijos de Sadoc.",
        url:         "https://qumranwatch.com/",
        email:       "contacto@qumranwatch.com",
        copyright:   "© Qumran Watch · Restauración del Calendario Solar Bíblico"
    }
};