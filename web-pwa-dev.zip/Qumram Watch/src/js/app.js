/**
 * ================================================================
 * QUMRAN WATCH — CONTROLADOR PRINCIPAL v14.0
 * Arquitectura: Web + PWA · Layout dos columnas · Arena y Oliva
 * ================================================================
 */

import { QumranData }    from './core/data.js';
import { QumranCalendar} from './core/calendar.js';
import { QumranSun }     from './core/sun.js';
import { QumranICS }     from './core/ics.js';
import { QumranContent } from './content.js';
import { ConsentManager} from './ui/consent.js';
import { ModalManager }  from './ui/modal.js';

// ─── Estado global ────────────────────────────────────────────
const State = {
    sunriseHour:    6.0,
    todayFiestaIdx: null,
    currentView:    'hoy',
};

let deferredPrompt = null;
let newWorker      = null;

// ─── Utilidad: setear texto en elemento por ID ────────────────
const setEl = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
};

const setHtml = (id, html) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
};

// ─── Service Worker ───────────────────────────────────────────
function registerSW() {
    if (!('serviceWorker' in navigator)) return;
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js').then(reg => {
            reg.addEventListener('updatefound', () => {
                newWorker = reg.installing;
                newWorker.addEventListener('statechange', () => {
                    if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                        showUpdateToast();
                    }
                });
            });
        }).catch(err => console.warn('[QW] SW:', err));
    });
}

function showUpdateToast() {
    const toast = document.getElementById('update-toast');
    const btn   = document.getElementById('btn-refresh');
    if (!toast || !btn) return;
    toast.style.display = 'flex';
    btn.addEventListener('click', () => {
        if (newWorker) newWorker.postMessage({ action: 'skipWaiting' });
        window.location.reload();
    }, { once: true });
}

// ─── PWA Install ──────────────────────────────────────────────
window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    const bar = document.getElementById('install-bar');
    if (bar) bar.classList.add('is-visible');
});

window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    const bar = document.getElementById('install-bar');
    if (bar) bar.classList.remove('is-visible');
});

// ─── Navegación ───────────────────────────────────────────────
function nav(viewId, isHistoryEvent = false) {
    // En mobile (PWA): mostrar/ocultar views
    document.querySelectorAll('.view').forEach(v => v.classList.remove('is-active'));
    const target = document.getElementById('view-' + viewId);
    if (target) target.classList.add('is-active');

    // Actualizar nav buttons (mobile)
    document.querySelectorAll('.nav-mobile__btn').forEach(btn => {
        const active = btn.dataset.view === viewId;
        btn.classList.toggle('is-active', active);
        btn.setAttribute('aria-current', active ? 'page' : 'false');
    });

    // Actualizar nav links (desktop header)
    document.querySelectorAll('.site-nav__link[data-view]').forEach(link => {
        const active = link.dataset.view === viewId;
        link.classList.toggle('is-active', active);
        link.setAttribute('aria-current', active ? 'page' : 'false');
    });

    State.currentView = viewId;

    if (!isHistoryEvent) {
        window.history.pushState({ view: viewId }, '', '#' + viewId);
    }

    // En desktop, scroll al contenido principal
    if (window.innerWidth > 768) {
        const mainContent = document.getElementById('main-content');
        if (mainContent) mainContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// ─── Geolocalización ──────────────────────────────────────────
function loadStoredLocation() {
    const lat = localStorage.getItem('qw_lat');
    const lng = localStorage.getItem('qw_lng');
    if (lat && lng) { updateSunData(parseFloat(lat), parseFloat(lng)); return true; }
    return false;
}

function getLocation() {
    if (!navigator.geolocation) return;
    if (!ConsentManager.hasConsent()) { ConsentManager.showBanner(); return; }

    const btn = document.getElementById('geo-btn');
    if (btn) btn.textContent = 'Buscando…';

    navigator.geolocation.getCurrentPosition(
        pos => {
            const { latitude: lat, longitude: lng } = pos.coords;
            localStorage.setItem('qw_lat', lat);
            localStorage.setItem('qw_lng', lng);
            updateSunData(lat, lng);
            if (btn) btn.textContent = '↻ Actualizar ubicación';
        },
        () => {
            // Fallback bíblico: Jerusalén
            updateSunData(31.7683, 35.2137);
            if (btn) btn.textContent = 'Usando Jerusalén (GPS no disponible)';
        },
        { timeout: 10000, enableHighAccuracy: false }
    );
}

function updateSunData(lat, lng) {
    const times = QumranSun.calcSunTimes(new Date(), lat, lng);
    if (times?.riseDecimal != null) {
        State.sunriseHour = times.riseDecimal;
        renderHoy();
        renderSidebar();
    }
    setEl('sun-rise',    times?.rise || '--:--');
    setEl('sun-set',     times?.set  || '--:--');
    setEl('sidebar-rise', times?.rise || '--:--');
    setEl('sidebar-set',  times?.set  || '--:--');

    const sunCard    = document.getElementById('sun-container');
    const sidebarSun = document.getElementById('sidebar-sun');
    const geoBtn     = document.getElementById('geo-btn');
    if (sunCard)    sunCard.classList.remove('is-hidden');
    if (sidebarSun) sidebarSun.classList.remove('is-hidden');
    if (geoBtn)     geoBtn.classList.remove('is-hidden');
}

// ─── Calcular fecha de hoy ajustada al amanecer ───────────────
function getTodayAdjusted() {
    let today = new Date();
    const h = today.getHours() + today.getMinutes() / 60;
    if (h < State.sunriseHour) today.setDate(today.getDate() - 1);
    return today;
}

// ─── Vigía: alertas de fiestas próximas ───────────────────────
function checkVigia(today, qToday) {
    const alertBox = document.getElementById('alert-container');
    if (!alertBox) return;
    let msg = '';

    if (qToday.idxSem === 5) {
        msg = '<strong>Día de Preparación</strong> — El Shabat entra al próximo amanecer.';
    }

    for (let i = 1; i <= 3; i++) {
        const future = new Date(today);
        future.setDate(future.getDate() + i);
        const qFut = QumranCalendar.calculate(future);
        if (!qFut || qFut.special) continue;
        const fIdx = QumranData.FIESTAS.findIndex(x => x.m === qFut.m && x.d === qFut.d);
        if (fIdx !== -1) {
            if (msg) msg += '<hr style="border:none;border-top:1px solid var(--color-terra-border);margin:8px 0">';
            msg += `<strong>En ${i} día${i > 1 ? 's' : ''}:</strong> ${QumranData.FIESTAS[fIdx].n}`;
        }
    }

    if (msg) {
        setHtml('alert-msg', msg);
        alertBox.classList.add('is-visible');
    } else {
        alertBox.classList.remove('is-visible');
    }

    // Yamim Noraim — 10 Días de Temor (Mes 7, Días 1-10)
    const teshuvaCard = document.getElementById('card-teshuva');
    if (teshuvaCard) {
        if (qToday.m === 6 && qToday.d >= 1 && qToday.d <= 10) {
            const tData = QumranData.YAMIM_NORAIM?.[qToday.d - 1];
            if (tData) {
                teshuvaCard.classList.remove('is-hidden');
                setEl('teshuva-cmd', `Día ${qToday.d} de 10: ${tData.t}`);
                setEl('teshuva-ref', `Lectura: ${tData.r}`);
            }
        } else {
            teshuvaCard.classList.add('is-hidden');
        }
    }

    // Omer
    let omerDay = 0;
    if (qToday.m === 0 && qToday.d >= 26) omerDay = qToday.d - 25;
    else if (qToday.m === 1) omerDay = 5 + qToday.d;
    else if (qToday.m === 2 && qToday.d <= 15) omerDay = 35 + qToday.d;

    const omerCard = document.getElementById('card-omer');
    if (omerCard) {
        if (omerDay > 0 && omerDay < 50) {
            omerCard.classList.remove('is-hidden');
            setEl('omer-count', omerDay);
        } else {
            omerCard.classList.add('is-hidden');
        }
    }
}

// ─── Render: Sidebar ──────────────────────────────────────────
function renderSidebar() {
    const today = getTodayAdjusted();
    const q     = QumranCalendar.calculate(today);
    if (!q || q.special) return;

    // Buscar próxima fiesta
    let nextFeast = null;
    let nextDays  = 0;

    for (let i = 0; i <= 365; i++) {
        const d = new Date(today);
        d.setDate(d.getDate() + i);
        const qd = QumranCalendar.calculate(d);
        if (!qd || qd.special) continue;
        const fIdx = QumranData.FIESTAS.findIndex(x => x.m === qd.m && x.d === qd.d);
        if (fIdx !== -1) {
            nextFeast = QumranData.FIESTAS[fIdx];
            nextDays  = i;
            break;
        }
    }

    // Contador
    if (nextFeast) {
        setEl('countdown-number', nextDays === 0 ? '¡Hoy!' : nextDays);
        setEl('countdown-unit',   nextDays === 0 ? '' : nextDays === 1 ? 'día' : 'días');
        setEl('countdown-feast',  nextFeast.n);
    }

    // Lista de fiestas próximas del año
    const feastList = document.getElementById('feast-list');
    if (!feastList) return;

    const year = today.getFullYear();
    const test = new Date(year, 2, 5);
    let rows   = '';
    let count  = 0;

    for (let i = 0; i < 400 && count < 8; i++) {
        const d  = new Date(test.getTime() + i * 86400000);
        const qd = QumranCalendar.calculate(d);
        if (!qd || qd.special) continue;

        const fIdx = QumranData.FIESTAS.findIndex(x => x.m === qd.m && x.d === qd.d);
        if (fIdx === -1) continue;

        const f    = QumranData.FIESTAS[fIdx];
        const diff = Math.round((d - today) / 86400000);
        if (diff < -1) continue;

        const dateStr  = d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
        const isToday  = diff === 0;
        const daysText = isToday ? 'Hoy' : diff === 1 ? 'Mañana' : `${diff}d`;

        rows += `
            <div class="feast-row"
                 role="button"
                 tabindex="0"
                 data-index="${fIdx}"
                 data-year="${year}"
                 aria-label="Fiesta: ${f.n}, ${dateStr}">
                <span class="feast-row__name">${f.n}</span>
                <span class="feast-row__date">${dateStr}</span>
                <span class="feast-row__days ${isToday ? 'is-today' : ''}">${daysText}</span>
            </div>`;
        count++;
    }

    feastList.innerHTML = rows || '<p class="u-muted" style="font-size:var(--text-sm)">Sin fiestas próximas</p>';
}

// ─── Render: Hoy ──────────────────────────────────────────────
function renderHoy() {
    const today = getTodayAdjusted();
    const q     = QumranCalendar.calculate(today);

    // Fecha gregoriana
    const gregStr = today.toLocaleDateString('es-ES', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    setEl('greg-date', gregStr);

    // Barra de fecha (strip en header)
    setEl('strip-date', gregStr);

    if (!q) return;

    if (q.special) {
        setEl('heb-date', 'Semana de Ajuste Solar');
        setEl('strip-heb', 'Semana de Ajuste Solar');
        return;
    }

    checkVigia(today, q);

    const hebStr = `${q.d} del ${QumranData.MESES[q.m]}`;
    setEl('heb-date',     hebStr);
    setEl('strip-heb',    hebStr);
    setEl('heb-dia',      QumranData.DIAS[q.idxSem]);
    setEl('heb-turno',    q.turno);
    setEl('heb-estacion', q.est);

    // Fiesta del día
    const fIdx = QumranData.FIESTAS.findIndex(x => x.m === q.m && x.d === q.d);
    State.todayFiestaIdx = fIdx !== -1 ? fIdx : null;

    const fiestaEl    = document.getElementById('heb-fiesta');
    const stripBadge  = document.getElementById('strip-badge');

    if (fiestaEl) {
        fiestaEl.textContent  = fIdx !== -1 ? `★ ${QumranData.FIESTAS[fIdx].n}` : '';
        fiestaEl.setAttribute('aria-label', fIdx !== -1 ? `Fiesta de hoy: ${QumranData.FIESTAS[fIdx].n}` : '');
    }
    if (stripBadge) {
        if (fIdx !== -1) {
            stripBadge.textContent = `★ ${QumranData.FIESTAS[fIdx].n}`;
            stripBadge.classList.remove('is-hidden');
        } else {
            stripBadge.classList.add('is-hidden');
        }
    }

    // Puertas del Sol
    document.querySelectorAll('.gate-dot').forEach((dot, i) => {
        const active = (i + 1) === q.puerta;
        dot.classList.toggle('is-active', active);
        dot.setAttribute('aria-current', active ? 'true' : 'false');
        dot.setAttribute('title', `Puerta ${i + 1}${active ? ' — activa hoy' : ''}`);
    });
    setEl('heb-puerta-num', `${q.puerta}ª Puerta Solar`);

    // Shabat progress
    const pct    = ((q.idxSem + 1) / 7) * 100;
    const fillEl = document.getElementById('shabat-progress');
    if (fillEl) fillEl.style.width = (q.idxSem === 6 ? 100 : pct) + '%';
    setEl('shabat-text',
        q.idxSem === 6
            ? '✡ Shabat Shalom'
            : `${6 - q.idxSem} día${6 - q.idxSem !== 1 ? 's' : ''} para el Shabat`
    );

    // Instrucción del Mesías
    const hIndex = q.dCountYear ? Math.floor(q.dCountYear / 7) % QumranData.HALAKHA.length : 0;
    const h = QumranData.HALAKHA[hIndex];
    if (h) {
        setEl('messiah-theme',     h.t  || '');
        setEl('messiah-hebrew',    h.h  || '');
        setEl('messiah-context',   h.c  ? `Contexto: ${h.c}` : '');
        setEl('messiah-philology', h.f  || '');
        setEl('messiah-quote',     h.q  ? `"${h.q}"` : '');
        setEl('messiah-action',    h.a  ? `${h.a}  (${h.r})` : '');

        // Sidebar: instrucción resumida
        setEl('sidebar-instr-quote',  h.q ? `"${h.q}"` : '');
        setEl('sidebar-instr-action', h.a ? `${h.a} · ${h.r}` : '');
    }

    // Lectura litúrgica
    let litSource = null;
    if (q.idxSem === 6) {
        litSource = QumranData.CANTICOS_SHABAT[
            Math.floor((q.dCountYear || 0) / 7) % QumranData.CANTICOS_SHABAT.length
        ];
        setEl('page-lit-type',  'Liturgia Celestial — Shabat');
        setEl('lit-main-title', 'Cántico del Sacrificio del Shabat');
    } else {
        litSource = QumranData.SALMOS[q.idxSem];
        setEl('page-lit-type',  'Shir Shel Yom — Cántico del Día');
        setEl('lit-main-title', 'Salmo del Templo');
    }

    if (litSource) {
        setEl('page-lit-title', litSource.t || '');

        // Contexto con separador decorativo
        const context = litSource.c
            ? `<blockquote>${litSource.c}</blockquote><div class="liturgy-separator"></div>`
            : '';

        // Convertir texto plano en párrafos HTML estructurados
        const rawText  = litSource.v || '';
        const parrafos = rawText
            .split(/\n\n+/)
            .filter(p => p.trim())
            .map(p => {
                const line = p.trim();
                // Versos numerados — destacar en negrita
                if (line.match(/^\d+[.:]/)) {
                    return '<p><strong>' + line + '</strong></p>';
                }
                return '<p>' + line.replace(/\n/g, '<br>') + '</p>';
            })
            .join('');

        setHtml('page-lit-text', context + parrafos);
    }
}

// ─── Render: Biblioteca ───────────────────────────────────────
function renderBiblioteca() {
    const container = document.getElementById('edu-grid');
    if (!container) return;

    container.innerHTML = QumranContent.ESTUDIOS.map((item, idx) => `
        <article class="article-card"
                 role="button"
                 tabindex="0"
                 data-index="${idx}"
                 aria-label="Estudio: ${item.titulo}">
            <span class="article-card__tag">${item.categoria}</span>
            <div class="article-card__title">${item.titulo}</div>
            <div class="article-card__excerpt">${item.subtitulo}</div>
            <span class="article-card__arrow" aria-hidden="true">→</span>
        </article>
    `).join('');
}

// ─── Render: Glosario ─────────────────────────────────────────
function renderGlosario() {
    const container = document.getElementById('glosario-grid');
    if (!container) return;

    container.innerHTML = QumranContent.GLOSARIO.map(item => `
        <div class="card">
            <h4 class="u-oliva" style="margin-bottom:var(--space-2)">${item.termino}</h4>
            <p style="margin:0;font-size:var(--text-sm);line-height:var(--leading-loose)">${item.definicion}</p>
        </div>
    `).join('');
}

// ─── Render: Comunidad ────────────────────────────────────────
function renderComunidad() {
    const c = QumranContent.COMUNIDAD;
    const introEl = document.getElementById('community-intro');
    if (introEl) introEl.textContent = c.intro;
}

// ─── Abrir estudio ────────────────────────────────────────────
function openEstudio(index) {
    const estudio = QumranContent.ESTUDIOS[index];
    if (!estudio) return;
    setEl('lec-title',    estudio.titulo);
    setEl('lec-tag',      estudio.categoria);
    setEl('lec-meta',     estudio.subtitulo);
    setHtml('lec-body',   estudio.texto);
    ModalManager.open('modal-lectura');
}

// ─── Abrir fiesta ─────────────────────────────────────────────
function openFiesta(index, forceYear) {
    const f    = QumranData.FIESTAS[index];
    const year = forceYear || new Date().getFullYear();

    // Calcular fecha gregoriana
    const anchor = new Date(year, 2, 5);
    let foundDate = null;
    for (let i = -20; i < 380; i++) {
        const d  = new Date(anchor.getTime() + i * 86400000);
        const qd = QumranCalendar.calculate(d);
        if (qd && !qd.special && qd.m === f.m && qd.d === f.d) { foundDate = d; break; }
    }

    let dateStr = foundDate
        ? foundDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })
        : 'Calculando…';

    if (foundDate && f.dur > 1) {
        const end = new Date(foundDate);
        end.setDate(end.getDate() + f.dur - 1);
        dateStr += ' al ' + end.toLocaleDateString('es-ES', { day: 'numeric', month: 'long' });
    }

    setEl('mod-title',      f.n);
    setEl('mod-fechas',     `${dateStr} (${year})`);
    setEl('mod-fechas-heb', `${f.d} del ${QumranData.MESES[f.m]} · ${f.es}`);
    setEl('mod-instr',      f.instr || '');
    setEl('mod-ref',        f.ref   || '');

    const noteEl = document.getElementById('mod-note');
    if (noteEl) { noteEl.style.display = f.nota ? 'block' : 'none'; if (f.nota) noteEl.textContent = f.nota; }

    const warnEl = document.getElementById('mod-warn');
    if (warnEl) warnEl.style.display = f.especial ? 'block' : 'none';

    ModalManager.open('modal-fiesta');
}

// ─── Render: Calendario ───────────────────────────────────────
function renderCalendar() {
    const yearInput = document.getElementById('cal-year');
    const year      = yearInput ? parseInt(yearInput.value) : new Date().getFullYear();
    const list      = document.getElementById('cal-lista');
    if (!list) return;

    list.innerHTML = `<div class="u-center u-muted" style="padding:var(--space-8)">Calculando ciclo sagrado…</div>`;

    setTimeout(() => {
        const test = new Date(year, 2, 5);
        let html   = '';

        for (let i = 0; i < 380; i++) {
            const d  = new Date(test.getTime() + i * 86400000);
            const qd = QumranCalendar.calculate(d);
            if (!qd || qd.special) continue;

            const fIdx = QumranData.FIESTAS.findIndex(x => x.m === qd.m && x.d === qd.d);
            if (fIdx === -1) continue;

            const f       = QumranData.FIESTAS[fIdx];
            let dateLabel = d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });

            if (f.dur > 1) {
                const end = new Date(d);
                end.setDate(end.getDate() + f.dur - 1);
                dateLabel += ' – ' + end.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
            }

            html += `
                <article class="feast-card"
                         role="button"
                         tabindex="0"
                         data-index="${fIdx}"
                         data-year="${year}"
                         aria-label="Fiesta ${f.n}, ${dateLabel}">
                    <div class="feast-card__name">${f.n}</div>
                    <div class="feast-card__desc">${f.es}</div>
                    <div class="feast-card__meta">
                        <span class="feast-card__greg">${dateLabel} ${year}</span>
                        <span class="feast-card__heb">${QumranData.MESES[qd.m]} · Día ${qd.d}</span>
                    </div>
                </article>`;
        }

        list.innerHTML = html || `<div class="card u-center u-muted">Sin fiestas para este año.</div>`;
    }, 60);
}


// ─── Buscador: Modo 1 — por nombre de fiesta ─────────────────
function renderSearchResults(query) {
    const container = document.getElementById('search-results');
    if (!container) return;

    const q = query.trim().toLowerCase();

    if (!q) {
        container.innerHTML = '<div class="search-empty">Escribí el nombre de una fiesta para buscar.</div>';
        return;
    }

    const year = new Date().getFullYear();
    const matches = QumranData.FIESTAS
        .map((f, idx) => ({ f, idx }))
        .filter(({ f }) =>
            f.n.toLowerCase().includes(q) ||
            f.es.toLowerCase().includes(q)
        );

    if (matches.length === 0) {
        container.innerHTML = '<div class="search-empty">No se encontraron fiestas. Probá con: Pesaj, Shavuot, Sucot, Yom Kipur, Tirosh, Yitzhar.</div>';
        return;
    }

    // Para cada fiesta encontrada, calcular fechas de 3 años consecutivos
    let html = '';

    matches.forEach(({ f, idx }) => {
        for (let y = year; y <= year + 2; y++) {
            const anchor = new Date(y, 2, 5);
            let foundDate = null;

            for (let i = -20; i < 380; i++) {
                const d  = new Date(anchor.getTime() + i * 86400000);
                const qd = QumranCalendar.calculate(d);
                if (qd && !qd.special && qd.m === f.m && qd.d === f.d) {
                    foundDate = d;
                    break;
                }
            }

            if (!foundDate) continue;

            const dateStr = foundDate.toLocaleDateString('es-ES', {
                weekday: 'long', day: 'numeric', month: 'long'
            });

            const dayName = foundDate.toLocaleDateString('es-ES', { weekday: 'long' });

            // Nota: día fijo de la semana
            const weekdayNote = `Siempre en ${dayName.charAt(0).toUpperCase() + dayName.slice(1)}`;

            html += `
                <div class="search-result-card"
                     role="button"
                     tabindex="0"
                     data-index="${idx}"
                     data-year="${y}"
                     aria-label="${f.n}, ${dateStr} ${y}">
                    <div class="search-result-card__name">${f.n} — ${y}</div>
                    <div class="search-result-card__dates">
                        <span class="search-result-card__greg">${dateStr} ${y}</span>
                        <span class="search-result-card__heb">${QumranData.MESES[f.m]} · Día ${f.d}</span>
                    </div>
                    <div class="search-result-card__note">${f.es} · ${weekdayNote}</div>
                </div>`;
        }
    });

    container.innerHTML = html || '<div class="search-empty">No se pudo calcular la fecha.</div>';
}

// ─── Buscador: Modo 2 — convertir fecha gregoriana ────────────
function convertGregorianDate() {
    const dayEl  = document.getElementById('conv-day');
    const monEl  = document.getElementById('conv-month');
    const yearEl = document.getElementById('conv-year');
    const result = document.getElementById('conv-result');

    if (!dayEl || !monEl || !yearEl || !result) return;

    const day   = parseInt(dayEl.value);
    const month = parseInt(monEl.value) - 1; // JS months 0-indexed
    const year  = parseInt(yearEl.value);

    // Validar campos vacíos
    if (!day || isNaN(month) || !year) {
        result.classList.remove('is-visible');
        return;
    }

    // Validar rango — el calendario ancla desde el 20 de marzo de 2019
    if (year < 2019) {
        result.classList.add('is-visible');
        result.innerHTML = '<div class="date-converter__result-special">'  +
            '⚠ El calendario solar restaurado tiene como punto de anclaje el ' +
            '<strong>20 de marzo de 2019</strong> — equinoccio de primavera que coincidió en ' +
            'Miércoles con Luna Llena en Jerusalén, replicando las condiciones de la Semana ' +
            'de la Creación (Génesis 1:14-19).<br><br>' +
            'Solo podemos calcular fechas desde el <strong>20 de marzo de 2019</strong> en adelante.' +
            '</div>';
        return;
    }

    if (year > 2100) {
        result.classList.add('is-visible');
        result.innerHTML = '<div class="date-converter__result-special">El rango de cálculo disponible es hasta el año 2100.</div>';
        return;
    }

    const date = new Date(year, month, day);

    // Validar que la fecha es real (ej: 31 de febrero no existe)
    if (date.getDate() !== day) {
        result.classList.add('is-visible');
        result.innerHTML = '<div class="date-converter__result-special">⚠ Fecha inválida — ese día no existe en el mes seleccionado.</div>';
        return;
    }

    const q = QumranCalendar.calculate(date);

    if (!q) {
        result.classList.add('is-visible');
        result.innerHTML = '<div class="date-converter__result-special">' +
            '⚠ No se pudo calcular para esa fecha. ' +
            'Recordá que el ancla del calendario es el <strong>20 de marzo de 2019</strong>. ' +
            'Fechas muy cercanas pueden estar en el período de transición.' +
            '</div>';
        return;
    }

    let mainText   = '';
    let detailText = '';
    let feastText  = '';

    if (q.special) {
        mainText   = 'Semana de Ajuste Solar';
        detailText = 'Este día es parte de los 7 días de ajuste entre ciclos anuales del calendario.';
    } else {
        mainText = `${q.d} del ${QumranData.MESES[q.m]}`;
        detailText = `
            <strong>${QumranData.DIAS[q.idxSem]}</strong> ·
            Turno: <strong>${q.turno}</strong> ·
            Estación: <strong>${q.est}</strong> ·
            ${q.puerta}ª Puerta Solar
        `;

        // Verificar si hay fiesta ese día
        const fIdx = QumranData.FIESTAS.findIndex(x => x.m === q.m && x.d === q.d);
        if (fIdx !== -1) {
            feastText = `★ ${QumranData.FIESTAS[fIdx].n} — ${QumranData.FIESTAS[fIdx].es}`;
        }

        // Verificar fiestas en los 3 días siguientes
        if (!feastText) {
            for (let i = 1; i <= 3; i++) {
                const next = new Date(date);
                next.setDate(next.getDate() + i);
                const qNext = QumranCalendar.calculate(next);
                if (!qNext || qNext.special) continue;
                const fNextIdx = QumranData.FIESTAS.findIndex(x => x.m === qNext.m && x.d === qNext.d);
                if (fNextIdx !== -1) {
                    feastText = `En ${i} día${i > 1 ? 's' : ''}: ${QumranData.FIESTAS[fNextIdx].n}`;
                    break;
                }
            }
        }
    }

    result.classList.add('is-visible');
    result.innerHTML = `
        <div class="date-converter__result-main">${mainText}</div>
        <div class="date-converter__result-detail">${detailText}</div>
        ${feastText ? `<div class="date-converter__result-feast">📅 ${feastText}</div>` : ''}
    `;
}

// ─── Buscador: alternar modos ─────────────────────────────────
function initSearch() {
    const tab1    = document.getElementById('search-tab-1');
    const tab2    = document.getElementById('search-tab-2');
    const mode1   = document.getElementById('search-mode-1');
    const mode2   = document.getElementById('search-mode-2');
    const input   = document.getElementById('search-input');
    const clearBtn = document.getElementById('search-clear');
    const convBtn = document.getElementById('conv-btn');

    if (!tab1 || !tab2) return;

    // Alternar entre modos
    tab1.addEventListener('click', () => {
        tab1.classList.add('is-active');
        tab2.classList.remove('is-active');
        mode1?.classList.remove('is-hidden');
        mode2?.classList.add('is-hidden');
        tab1.setAttribute('aria-selected', 'true');
        tab2.setAttribute('aria-selected', 'false');
    });

    tab2.addEventListener('click', () => {
        tab2.classList.add('is-active');
        tab1.classList.remove('is-active');
        mode2?.classList.remove('is-hidden');
        mode1?.classList.add('is-hidden');
        tab2.setAttribute('aria-selected', 'true');
        tab1.setAttribute('aria-selected', 'false');
    });

    // Búsqueda en tiempo real
    if (input) {
        input.addEventListener('input', () => {
            const val = input.value;
            if (clearBtn) clearBtn.classList.toggle('is-visible', val.length > 0);
            renderSearchResults(val);
        });

        input.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                input.value = '';
                if (clearBtn) clearBtn.classList.remove('is-visible');
                renderSearchResults('');
            }
        });
    }

    // Limpiar búsqueda
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (input) input.value = '';
            clearBtn.classList.remove('is-visible');
            renderSearchResults('');
            input?.focus();
        });
    }

    // Convertir fecha gregoriana
    if (convBtn) {
        convBtn.addEventListener('click', convertGregorianDate);
    }

    // Convertir también con Enter en cualquier campo
    ['conv-day', 'conv-month', 'conv-year'].forEach(id => {
        document.getElementById(id)?.addEventListener('keydown', e => {
            if (e.key === 'Enter') convertGregorianDate();
        });
    });

    // Delegación de clicks en resultados de búsqueda
    document.getElementById('search-results')?.addEventListener('click', e => {
        const card = e.target.closest('[data-index]');
        if (card) openFiesta(parseInt(card.dataset.index), parseInt(card.dataset.year));
    });
    document.getElementById('search-results')?.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
            const card = e.target.closest('[data-index]');
            if (card) { e.preventDefault(); openFiesta(parseInt(card.dataset.index), parseInt(card.dataset.year)); }
        }
    });

    // Estado inicial
    renderSearchResults('');
}

// ─── Setup de listeners ───────────────────────────────────────
function setupListeners() {

    // Nav mobile (botones inferiores)
    document.querySelectorAll('.nav-mobile__btn').forEach(btn => {
        btn.addEventListener('click', () => nav(btn.dataset.view));
    });

    // Nav desktop (links del header)
    document.querySelectorAll('.site-nav__link[data-view]').forEach(link => {
        link.addEventListener('click', e => {
            e.preventDefault();
            nav(link.dataset.view);
            // Cerrar menú mobile si está abierto
            document.getElementById('mobile-menu')?.classList.remove('is-open');
        });
    });

    // Hamburguesa mobile
    const navToggle   = document.getElementById('nav-toggle');
    const mobileMenu  = document.getElementById('mobile-menu');
    if (navToggle && mobileMenu) {
        navToggle.addEventListener('click', () => {
            const open = mobileMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', open);
        });
    }

    // Instalar PWA
    document.getElementById('btn-install-app')?.addEventListener('click', async () => {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        await deferredPrompt.userChoice;
        deferredPrompt = null;
        document.getElementById('install-bar')?.classList.remove('is-visible');
    });

    // GPS
    document.getElementById('geo-btn')?.addEventListener('click', () => {
        if (ConsentManager.hasConsent()) getLocation();
        else ConsentManager.showBanner();
    });

    // Fiesta del día (badge)
    document.getElementById('heb-fiesta')?.addEventListener('click', () => {
        if (State.todayFiestaIdx !== null) openFiesta(State.todayFiestaIdx);
    });

    // Strip badge
    document.getElementById('strip-badge')?.addEventListener('click', () => {
        if (State.todayFiestaIdx !== null) openFiesta(State.todayFiestaIdx);
    });

    // Ver detalles del día (strip)
    document.getElementById('strip-detail-btn')?.addEventListener('click', () => nav('hoy'));

    // Puertas del Sol — abrir explicación
    document.getElementById('gates-info-btn')?.addEventListener('click', () => {
        ModalManager.open('modal-puertas');
    });

    // Cerrar modales
    document.getElementById('btn-close-modal')?.addEventListener('click',   () => ModalManager.close('modal-fiesta'));
    document.getElementById('btn-close-lectura')?.addEventListener('click', () => ModalManager.close('modal-lectura'));
    document.getElementById('btn-close-puertas')?.addEventListener('click', () => ModalManager.close('modal-puertas'));

    // Biblioteca — delegación de eventos
    document.getElementById('edu-grid')?.addEventListener('click', e => {
        const card = e.target.closest('[data-index]');
        if (card) openEstudio(parseInt(card.dataset.index));
    });
    document.getElementById('edu-grid')?.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
            const card = e.target.closest('[data-index]');
            if (card) { e.preventDefault(); openEstudio(parseInt(card.dataset.index)); }
        }
    });

    // Calendario — delegación
    document.getElementById('cal-lista')?.addEventListener('click', e => {
        const card = e.target.closest('[data-index]');
        if (card) openFiesta(parseInt(card.dataset.index), parseInt(card.dataset.year));
    });
    document.getElementById('cal-lista')?.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
            const card = e.target.closest('[data-index]');
            if (card) { e.preventDefault(); openFiesta(parseInt(card.dataset.index), parseInt(card.dataset.year)); }
        }
    });

    // Sidebar — lista de fiestas
    document.getElementById('feast-list')?.addEventListener('click', e => {
        const row = e.target.closest('[data-index]');
        if (row) openFiesta(parseInt(row.dataset.index), parseInt(row.dataset.year));
    });

    // Calendario — botones
    document.getElementById('btn-render-cal')?.addEventListener('click', renderCalendar);
    document.getElementById('btn-export-ics')?.addEventListener('click', () => {
        const y = parseInt(document.getElementById('cal-year')?.value || new Date().getFullYear());
        QumranICS.generateAndDownload(y);
    });

    // Comunidad — links externos
    document.getElementById('btn-podcast')?.addEventListener('click', () => {
        window.open(QumranContent.COMUNIDAD.podcast.url, '_blank', 'noopener');
    });
    document.getElementById('btn-instituto')?.addEventListener('click', () => {
        window.open(QumranContent.COMUNIDAD.instituto.url, '_blank', 'noopener');
    });
    document.getElementById('btn-telegram')?.addEventListener('click', () => {
        window.open(QumranContent.COMUNIDAD.telegram.url, '_blank', 'noopener');
    });

    // Revocar consentimiento
    document.getElementById('btn-revoke-consent')?.addEventListener('click', () => {
        ConsentManager.revoke();
        alert('Consentimiento revocado. La app usará Jerusalén como referencia.');
    });

    // Historial del navegador
    window.addEventListener('popstate', e => {
        const view = e.state?.view || 'hoy';
        nav(view, true);
    });
}

// ─── Init ─────────────────────────────────────────────────────
function init() {
    registerSW();
    setupListeners();

    // Consentimiento RGPD
    ConsentManager.init(() => {
        if (!loadStoredLocation()) getLocation();
    });
    if (ConsentManager.hasConsent() && !loadStoredLocation()) getLocation();

    // Render inicial
    renderHoy();
    renderSidebar();
    renderBiblioteca();
    renderGlosario();
    renderComunidad();

    // URL hash inicial
    const hash = window.location.hash.slice(1);
    if (hash && document.getElementById('view-' + hash)) {
        nav(hash, true);
    } else {
        window.history.replaceState({ view: 'hoy' }, '', '#hoy');
    }

    // Inicializar buscador
    initSearch();

    // Render del calendario al entrar a esa sección
    document.querySelector('[data-view="cal"]')?.addEventListener('click', () => {
        setTimeout(() => {
            if (!document.getElementById('cal-lista')?.children.length) renderCalendar();
        }, 100);
    }, { once: true });
}

document.addEventListener('DOMContentLoaded', init);

export { nav, renderHoy, openFiesta, openEstudio, State };
