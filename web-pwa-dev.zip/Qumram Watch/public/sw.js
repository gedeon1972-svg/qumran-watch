/**
 * sw.js — Service Worker v13.0
 * Estrategia: Cache First con revalidación en background (Stale-While-Revalidate)
 */

const CACHE_VERSION = 'qumran-v13.0';
const CACHE_STATIC  = `${CACHE_VERSION}-static`;

const STATIC_ASSETS = [
    './',
    './index.html',
    './manifest.json',
    './icon.png',
    './src/css/styles.css',
    './src/css/tokens.css',
    './src/css/base.css',
    './src/css/components.css',
    './src/js/app.js',
    './src/js/core/data.js',
    './src/js/core/calendar.js',
    './src/js/core/sun.js',
    './src/js/core/ics.js',
    './src/js/ui/consent.js',
    './src/js/ui/modal.js',
    './src/css/fonts/david-libre-v17-latin-regular.woff2',
    './src/css/fonts/david-libre-v17-latin-700.woff2',
    './src/css/fonts/cinzel-v26-latin-regular.woff2',
    './src/css/fonts/cinzel-v26-latin-700.woff2',
];

// ── Instalación ──────────────────────────────────────────────────────────────
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_STATIC).then(cache => {
            console.log('[SW v13] Instalando caché estático');
            return Promise.allSettled(
                STATIC_ASSETS.map(url =>
                    cache.add(url).catch(err =>
                        console.warn(`[SW] No se pudo cachear: ${url}`, err)
                    )
                )
            );
        }).then(() => self.skipWaiting())
    );
});

// ── Activación ───────────────────────────────────────────────────────────────
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(
                keys.filter(k => k !== CACHE_STATIC)
                    .map(k => {
                        console.log('[SW v13] Eliminando caché antiguo:', k);
                        return caches.delete(k);
                    })
            )
        ).then(() => self.clients.claim())
    );
});

// ── Fetch: Stale-While-Revalidate ─────────────────────────────────────────────
self.addEventListener('fetch', event => {
    if (event.request.method !== 'GET') return;

    // No interceptar peticiones a otros orígenes
    const url = new URL(event.request.url);
    if (url.origin !== location.origin) return;

    event.respondWith(
        caches.match(event.request).then(cached => {
            const fetchPromise = fetch(event.request).then(response => {
                if (response && response.status === 200) {
                    const clone = response.clone();
                    caches.open(CACHE_STATIC).then(cache => cache.put(event.request, clone));
                }
                return response;
            }).catch(() => null);

            // Devolver del caché inmediatamente, actualizar en background
            return cached || fetchPromise;
        }).catch(() => {
            // Offline fallback: devolver index.html para navegación
            if (event.request.destination === 'document') {
                return caches.match('./index.html');
            }
        })
    );
});

// ── Mensajes desde la app ─────────────────────────────────────────────────────
self.addEventListener('message', event => {
    if (event.data?.action === 'skipWaiting') {
        self.skipWaiting();
    }
});